export default function PostShowPage() {
  return <div>Post Show Page</div>;
}
